﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class EnemyScript : MonoBehaviour
{    
    public GameObject enemyProjectile;
    public float MoveSpeed;
    public Transform targetplayer;
    private Rigidbody2D rb;

    private Vector3 movement;
    // Start is called before the first frame update
    void Start()
    {
        rb = this.GetComponent<Rigidbody2D>();
        float delay = Random.Range(2f, 10f);
        float rate = Random.Range(2f, 8f);
        InvokeRepeating("Fire",delay,rate);
    }

    private void Update()
    {
        Vector3 direction = targetplayer.position - transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x)*Mathf.Rad2Deg;
        rb.rotation = angle;
        direction.Normalize();
        movement = direction;
        // Debug.Log(direction);
    }

    void moveCharacter(Vector3 direction)
    {
        rb.MovePosition(transform.position+(direction*MoveSpeed*Time.deltaTime));
        
    }

    // Update is called once per frame
    private void Fire()
    {
        int i = Random.Range(0, 100);
        if (i > 5)
        { 
            Instantiate(enemyProjectile, new Vector2(transform.position.x, transform.position.y), Quaternion.identity);
        }
    }
}
