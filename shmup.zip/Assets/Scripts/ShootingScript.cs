﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class ShootingScript : MonoBehaviour
{
    public Transform firePoint;
    public GameObject PrimarybulletPrefab;
    public GameObject SecondarybulletPrefab;
    public float bulletForce = 20f;
    public int FireMode = 0;
    // Update is called once per frame
    public GameObject player;
    private PlayerScript plscript;
    void Update()
    {
        plscript = player.GetComponent<PlayerScript>();
        if (plscript.health > 0.5)
        {
            FireMode = 0;
        }
        else if(plscript.health<0.5 && plscript.health>0.3)
        {
            FireMode = 1;
        }
        else
        {
            FireMode = 2;
        }
        if (Input.GetButtonDown("Fire1"))
        {
            if (FireMode == 0)
            {
                Shoot();
            }
            else if (FireMode == 1)
            {
                Shoot2();
            }
            else if (FireMode == 2)
            {
                Shoot3();
            }
            
        }
    }

    void Shoot()
    {
        GameObject bullet = Instantiate(PrimarybulletPrefab, firePoint.position, firePoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);

    }

    void Shoot2()
    {
        
        GameObject bullet = Instantiate(PrimarybulletPrefab, firePoint.position, firePoint.rotation);
        GameObject bullet2 = Instantiate(PrimarybulletPrefab, firePoint.position, firePoint.rotation );
        GameObject bullet3 = Instantiate(PrimarybulletPrefab, firePoint.position, firePoint.rotation);
        GameObject bullet4 = Instantiate(PrimarybulletPrefab, firePoint.position, firePoint.rotation);
        GameObject bullet5 = Instantiate(PrimarybulletPrefab, firePoint.position, firePoint.rotation);
        // *Quaternion.Euler(0,-70,-90)
        bullet.transform.Rotate(0,0,UnityEngine.Random.Range(-40,40));
        bullet2.transform.Rotate(0,0,UnityEngine.Random.Range(-40,40));
        bullet3.transform.Rotate(0,0,UnityEngine.Random.Range(-40,40));
        bullet4.transform.Rotate(0,0,UnityEngine.Random.Range(-40,40));
        bullet5.transform.Rotate(0,0,UnityEngine.Random.Range(-40,40));
        
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);
        Rigidbody2D rb2 = bullet2.GetComponent<Rigidbody2D>();
        rb2.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);
        Rigidbody2D rb3 = bullet3.GetComponent<Rigidbody2D>();
        rb3.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);
        Rigidbody2D rb4 = bullet2.GetComponent<Rigidbody2D>();
        rb4.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);
        Rigidbody2D rb5 = bullet3.GetComponent<Rigidbody2D>();
        rb5.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);
    }

    void Shoot3()
    {
        GameObject bullet = Instantiate(SecondarybulletPrefab, firePoint.position, firePoint.rotation);
        bullet.transform.Rotate(0,0,90);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);
    }
    
}
